const db = require("../routes/db-config");
const bcrypt = require("bcryptjs");

const register = async (req, res) => {
    const { id, psword: Napssword } = req.body
    if (!id || !Napssword) return res.json({ status: "error", error: "아이디나 비밀번호를 입력해주세요" })
    else {
        db.query('SELECT id FROM users01 WHERE id = ?', [id], async (err, result) => {
            if (err) throw err;
            if (result[0]) return res.json({ status: "error", error: "중복되는 아이디 입니다"})
            else {
                const psword = await bcrypt.hash(Napssword, 8);
                db.query('INSERT INTO users01 SET ?', { id: id, psword: psword }, (error, results) => {
                    if (err) throw err;
                    return res.json({ status: "success", success: "회원가입이 완료 됐습니다" })
                })
            }
        })
    }
}
module.exports = register;